import { Component, OnInit } from '@angular/core';
import {AddshopsService} from "./addshops.service";
import {FormControl, FormGroup} from "@angular/forms";
import {ShopDetails} from "../../ShopDetails";

@Component({
  selector: 'app-addshops',
  templateUrl: './addshops.component.html',
  styleUrls: ['./addshops.component.css']
})
export class AddshopsComponent implements OnInit {
  shop : ShopDetails = new ShopDetails();
  constructor(private service: AddshopsService) {}
  ngOnInit(): void {
    this.addshops();

  }
  addShops = new FormGroup({
    shopName : new FormControl(),
    address : new FormControl(),
    town : new FormControl(),
    district : new FormControl(),
    state : new FormControl(),
    country : new FormControl(),
    pincode : new FormControl(),

  });
  addshops()
  {
    this.shop.shopName = this.addShops.value.shopName;
    this.shop.address = this.addShops.value.address;
    this.shop.town = this.addShops.value.town;
    this.shop.district = this.addShops.value.district;
    this.shop.state = this.addShops.value.state;
    this.shop.country = this.addShops.value.country;
    this.shop.pincode = this.addShops.value.pincode;

  }
}


