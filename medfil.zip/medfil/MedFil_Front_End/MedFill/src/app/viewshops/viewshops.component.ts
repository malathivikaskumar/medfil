import { Component, OnInit } from '@angular/core';
import {ViewshopsService} from "./viewshops.service";
import {UserDetails} from "../../UserDetails";
import {ShopDetails} from "../../ShopDetails";
import {MainService} from "../main.service";

@Component({
  selector: 'app-viewshops',
  templateUrl: './viewshops.component.html',
  styleUrls: ['./viewshops.component.css']
})
export class ViewshopsComponent implements OnInit {

  userId: number = 0;

  shopDetailsArr: ShopDetails[] = [];

  constructor(private service : ViewshopsService,private mainService: MainService) { }

  ngOnInit(): void {
    this.mainService.userDetails.subscribe(value => {
      this.userId = value.userId;
    });
    this.viewshops();
  }

  viewshops()
  {
    this.service.viewshops(this.userId).subscribe(value => {
      this.shopDetailsArr = <ShopDetails[]>value;
      console.log(this.shopDetailsArr);
      this.mainService.changeShopDetails(<ShopDetails[]>this.shopDetailsArr)
    })

  }

}
