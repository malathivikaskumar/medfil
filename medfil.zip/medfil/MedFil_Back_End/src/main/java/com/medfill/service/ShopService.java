package com.medfill.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medfill.dao.ShopDAO;
import com.medfill.vo.ShopDetails;

@Service
public class ShopService extends BaseService {
	@Autowired
	private ShopDAO dao;

	public ArrayList<ShopDetails> viewshops(int userId) {
		ArrayList<ShopDetails> list = null;
		Connection con = null;
		try {
			con = getConnection();
			list = dao.viewshops(con, userId);
		} catch (SQLException e) {
			rollback(con);
			e.printStackTrace();
		} finally {
			close(con);
		}
		return list;

	}
}
