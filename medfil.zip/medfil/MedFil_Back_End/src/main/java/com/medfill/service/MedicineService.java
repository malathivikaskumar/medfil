package com.medfill.service;

import java.sql.Connection;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medfill.dao.MedicineDAO;
import com.medfill.dao.ShopDAO;
import com.medfill.vo.MedicineDetails;
import com.medfill.vo.Msg;

@Service
public class MedicineService extends BaseService {

	@Autowired
	private MedicineDAO dao;

	public Msg addMedicine(MedicineDetails medicineDetails) {
		Msg msg = new Msg();
		Connection con = null;
		try {
			con = getConnection();

			ArrayList<Integer> shopIdList = medicineDetails.getShopIdList();

			for (Integer shopId : shopIdList) {

				medicineDetails.setShopId(shopId);
				int i = dao.addMedicine(con, medicineDetails);
				if (i < 0) {
					throw new Exception();
				} else {
					msg.setSuccessMsg("succussfully inserted");
				}
				
			}
			commit(con);

		} catch (Exception e) {
			rollback(con);
			msg.setErrorMsg("Exception in the Add medicine flow: ");
		} finally {
			close(con);
		}
		return msg;
	}

}
