package com.medfill.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.medfill.vo.MedicineDetails;

@Repository
public class MedicineDAO {
	
	public int addMedicine(Connection con, MedicineDetails medicineDetails) throws SQLException
	{
		int i =0;
		try {
			PreparedStatement ps = con.prepareStatement("insert into medicine_tbl(med_name,med_quantity,med_expiry_date,med_description,med_cost,shop_id) values(?,?,?,?,?,?)");
			ps.setString(1, medicineDetails.getMedName());
			ps.setInt(2, medicineDetails.getMedQuantity());
			ps.setString(3, medicineDetails.getMedExpiryDate().toString());
			ps.setString(4, medicineDetails.getMedDescription());
			ps.setDouble(5, medicineDetails.getMedCost());
			ps.setInt(6, medicineDetails.getShopId());
			
		
			i = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}
		return i;
		
	}

}
