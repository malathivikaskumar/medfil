export class ShopDetails{
  shopId : number =0;
  shopName : string = '';
  address : string = '';
  town : string = '';
  district : string = '';
  state : string = '';
  country : string = '';
  pincode : number = 0;
  userId: number = 0;
}

