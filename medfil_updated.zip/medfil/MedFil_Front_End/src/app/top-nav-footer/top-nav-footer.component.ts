import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-nav-footer',
  templateUrl: './top-nav-footer.component.html',
  styleUrls: ['./top-nav-footer.component.css']
})
export class TopNavFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
