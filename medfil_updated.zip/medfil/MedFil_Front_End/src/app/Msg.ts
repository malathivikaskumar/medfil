import {UserDetails} from "../UserDetails";

export class Msg {
  successMsg: string = '';
  errorMsg: string = '';
  userDetails: UserDetails | null = null;
}
