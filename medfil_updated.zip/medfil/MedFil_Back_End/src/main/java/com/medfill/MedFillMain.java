package com.medfill;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedFillMain {

	public static void main(String[] args) {
		SpringApplication.run(MedFillMain.class, args);
	}

}
